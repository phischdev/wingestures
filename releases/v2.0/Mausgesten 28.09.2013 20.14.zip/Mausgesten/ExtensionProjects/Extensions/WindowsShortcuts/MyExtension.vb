﻿Imports ExtensionContract
Imports System.ComponentModel.Composition
Imports System.IO
Imports System.Xml
Imports WindowsInput

'<ExtensionMetadata("Philipp Schimmelfennig", "BasicShortcuts", "Empty", "1.0")> _
<Export(GetType(IExtensionContract))> _
Public Class BasicShortcuts : Implements IExtensionContract

    Public Sub New()

    End Sub

    Public Function GetUI() As Xml.XmlDocument Implements IExtensionContract.GetUI
        Return PrepareMenu.Prepare(System.Reflection.Assembly.GetExecutingAssembly)
    End Function

    Dim LastMinimized As New LastMinimized

    Public Sub Action(ID As String, e As ActionEventArgs) Implements IExtensionContract.Action
        Select Case ID
            Case "desktop"
                InputSimulator.SimulateModifiedKeyStroke({WindowsInput.VirtualKeyCode.LWIN}, {VirtualKeyCode.VK_D})

            Case "explorer"
                Process.Start("explorer.exe")
            Case "music"
                Process.Start("explorer.exe",
                Environment.GetFolderPath(Environment.SpecialFolder.MyMusic))
            Case "pictures"
                Process.Start("explorer.exe",
                Environment.GetFolderPath(Environment.SpecialFolder.MyPictures))
            Case "videos"
                Process.Start("explorer.exe",
                Environment.GetFolderPath(Environment.SpecialFolder.MyVideos))
            Case "documents"
                Process.Start("explorer.exe",
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments))

            Case "maximize"
                Dim wpTemp As Win32.WINDOWPLACEMENT
                Win32.User.GetWindowPlacement(e.WindowHandle, wpTemp)
                Dim WindowState As Integer = wpTemp.showCmd
                If WindowState = Win32.User.SW_SHOWMAXIMIZED Then
                    Win32.User.ShowWindow(e.WindowHandle, Win32.User.SW_RESTORE)
                Else
                    Win32.User.ShowWindow(e.WindowHandle, Win32.User.SW_MAXIMIZE)
                End If
            Case "minimize"
                LastMinimized = New LastMinimized With {.Handle = e.WindowHandle, .ShowState = GetWindowShowState(e.WindowHandle)}
                Win32.User.ShowWindow(e.WindowHandle, Win32.User.SW_MINIMIZE)
            Case "get back"
                Win32.User.ShowWindow(LastMinimized.Handle, LastMinimized.ShowState)
            Case "close"
                Win32.User.PostMessage(e.WindowHandle, Win32.User.WM_CLOSE, 0, 0)
        End Select
    End Sub

    Public Function Closing() As Object Implements IExtensionContract.Closing
        Return Nothing
    End Function

    Public Sub Loaded() Implements IExtensionContract.Loaded

    End Sub

    Public Sub Pause() Implements IExtensionContract.Pause

    End Sub

    Public Sub Reactivate() Implements IExtensionContract.Reactivate

    End Sub
End Class
