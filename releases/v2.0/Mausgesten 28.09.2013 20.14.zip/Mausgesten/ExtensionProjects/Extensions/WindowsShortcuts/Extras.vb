﻿Module Extras
    Public Structure LastMinimized
        Public Handle As IntPtr
        Public ShowState As Integer
    End Structure
    Public Function GetWindowShowState(WindowHandle As IntPtr) As Integer
        Dim wpTemp As Win32.WINDOWPLACEMENT
        Win32.User.GetWindowPlacement(WindowHandle, wpTemp)
        Return wpTemp.showCmd
    End Function
End Module