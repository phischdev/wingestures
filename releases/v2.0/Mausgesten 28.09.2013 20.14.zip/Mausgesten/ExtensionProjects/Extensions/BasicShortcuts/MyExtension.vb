﻿Imports ExtensionContract
Imports System.ComponentModel.Composition
Imports System.IO
Imports System.Xml
Imports WindowsInput

<Export(GetType(IExtensionContract))> _
Public Class BasicShortcuts : Implements IExtensionContract

    Public Sub New()
        Debug.Print("New")
    End Sub

    Public Sub Loaded() Implements IExtensionContract.Loaded
        Debug.Print("Loaded")
    End Sub

    Public Sub Action(ID As String, e As ActionEventArgs) Implements IExtensionContract.Action
        Debug.Print(Date.Now.TimeOfDay.ToString & " received " & ID)

        Select Case ID
            Case "play"
                InputSimulator.SimulateKeyPress(VirtualKeyCode.MEDIA_PLAY_PAUSE)
            Case "stop"
                InputSimulator.SimulateKeyPress(VirtualKeyCode.MEDIA_STOP)
            Case "forward"
                InputSimulator.SimulateKeyPress(VirtualKeyCode.MEDIA_NEXT_TRACK)
            Case "backward"
                InputSimulator.SimulateKeyPress(VirtualKeyCode.MEDIA_PREV_TRACK)
            Case "open"
                InputSimulator.SimulateModifiedKeyStroke({VirtualKeyCode.CONTROL}, {VirtualKeyCode.VK_O})
        End Select
    End Sub

    Public Function Closing() As Object Implements IExtensionContract.Closing
        Return Nothing
    End Function

    Public Sub Pause() Implements IExtensionContract.Pause
        Debug.Print("Paused")
    End Sub

    Public Sub Reactivate() Implements IExtensionContract.Reactivate
        Debug.Print("Resumed")
    End Sub

    Public Function GetUI() As Xml.XmlDocument Implements IExtensionContract.GetUI
        Return PrepareMenu.Prepare(System.Reflection.Assembly.GetExecutingAssembly)
    End Function
End Class
