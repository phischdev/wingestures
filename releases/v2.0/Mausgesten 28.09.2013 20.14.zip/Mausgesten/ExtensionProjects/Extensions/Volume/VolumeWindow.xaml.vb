﻿Imports CoreAudioApi
Imports System.Windows.Controls.Primitives
Imports System.Windows
Imports System.Threading.Tasks
Imports System.Reflection
Imports System.Windows.Media

Public Class VolumeWindow
    Private Device As MMDevice
    Private Sub VolumeWindow_Activated(sender As Object, e As EventArgs) Handles Me.Activated

    End Sub

    Private Sub VolumeWindow_Deactivated(sender As Object, e As EventArgs) Handles Me.Deactivated
        Me.Close()
    End Sub

    Private Sub VolumeWindow_Loaded(sender As Object, e As Windows.RoutedEventArgs) Handles Me.Loaded
        Volumeslider.Value = Device.AudioEndpointVolume.MasterVolumeLevelScalar

        Dim mpoint = System.Windows.Forms.Control.MousePosition()
        Dim MousePosition As New Point(mpoint.X, mpoint.Y)

        Dim sliderpoint = Volumeslider.TranslatePoint(New Point(Volumeslider.Value * Volumeslider.ActualWidth, 0), Me)

        Me.Left = MousePosition.X - sliderpoint.X
        Me.Top = MousePosition.Y - Me.ActualHeight / 2


    End Sub

    Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()
        Dim devEm As New MMDeviceEnumerator
        Device = devEm.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia)

        Dim thisassembly As Assembly = Assembly.GetExecutingAssembly
        Dim imgstream As IO.Stream = thisassembly.GetManifestResourceStream(thisassembly.GetName.Name & "." & "speaker1")
        'img1.Source = "Assets/speaker1.png"


        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.

    End Sub

    Private Sub Volumeslider_MouseDown(sender As Object, e As Input.MouseButtonEventArgs) Handles Volumeslider.MouseDown
        Me.Close()
    End Sub

    Private Sub Volumeslider_MouseLeftButtonDown(sender As Object, e As Input.MouseButtonEventArgs) Handles Volumeslider.MouseLeftButtonDown
        Me.Close()
    End Sub

    Private Sub Volumeslider_MouseMove(sender As Object, e As Input.MouseEventArgs) Handles Volumeslider.MouseMove
        Dim x = e.GetPosition(Volumeslider).X
        Volumeslider.Value = x / Volumeslider.ActualWidth

    End Sub

    Private Sub Volumeslider_ValueChanged(sender As Object, e As Windows.RoutedPropertyChangedEventArgs(Of Double)) Handles Volumeslider.ValueChanged
        Device.AudioEndpointVolume.MasterVolumeLevelScalar = Volumeslider.Value
    End Sub

    Private Function GetThumb(slider As Windows.Controls.Slider) As Thumb
        Dim track = TryCast(slider.Template.FindName("Thumb", slider), Thumb)
        Return If(track Is Nothing, Nothing, track)
    End Function

    Private Sub VolumeWindow_MouseDown(sender As Object, e As Input.MouseButtonEventArgs) Handles Me.MouseDown
        Me.Close()
    End Sub

    Private Sub VolumeWindow_MouseLeftButtonDown(sender As Object, e As Input.MouseButtonEventArgs) Handles Me.MouseLeftButtonDown
        Me.Close()
    End Sub
End Class
