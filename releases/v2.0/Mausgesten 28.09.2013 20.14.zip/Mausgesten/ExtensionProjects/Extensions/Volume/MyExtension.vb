﻿Imports ExtensionContract
Imports System.ComponentModel.Composition
Imports System.IO
Imports System.Xml

<Export(GetType(IExtensionContract))> _
Public Class BasicShortcuts : Implements IExtensionContract

    Public Sub New()

    End Sub

    Public Sub Loaded() Implements IExtensionContract.Loaded

    End Sub

    Public Sub Action(ID As String, e As ActionEventArgs) Implements IExtensionContract.Action
        Select Case ID
            Case "openwindow"
                'Dim vw As New VolumeWindow()
                'vw.Show()
                Dim t As New Threading.Thread(Sub()
                                                  Dim vw As New VolumeWindow()
                                                  vw.Show()
                                                  AddHandler vw.Closed, Sub()
                                                                            vw.Dispatcher.InvokeShutdown()
                                                                        End Sub
                                                  System.Windows.Threading.Dispatcher.Run()
                                              End Sub)
                t.SetApartmentState(Threading.ApartmentState.STA)
                t.IsBackground = True
                t.Start()
        End Select
    End Sub

    Public Function Closing() As Object Implements IExtensionContract.Closing
        Return Nothing
    End Function

    Public Sub Pause() Implements IExtensionContract.Pause

    End Sub

    Public Sub Reactivate() Implements IExtensionContract.Reactivate

    End Sub

    Public Function GetUI() As Xml.XmlDocument Implements IExtensionContract.GetUI
        Return PrepareMenu.Prepare(System.Reflection.Assembly.GetExecutingAssembly)
    End Function
End Class
