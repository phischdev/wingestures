﻿Imports System.Xml
Imports SharedMethods
Public Class Menu_TreeViewVM
    Dim Menü As SharedMethods.Menü

    Public ReadOnly Property TreeViewData
        Get
            Dim RootItem As New TreeViewItem
            RootItem.IsExpanded = True
            RootItem.Header = Menü.Titel
            GetSubMenu(RootItem, Menü)
            Return RootItem
        End Get
    End Property

    Private Sub GetSubMenu(RootItem As TreeViewItem, RootMenu As Menü)
        For Each submenü As Menü In RootMenu.Untermenüs
            If Not submenü Is Nothing Then
                Dim titem As New TreeViewItem
                titem.IsExpanded = True
                titem.Header = submenü.Titel
                GetSubMenu(titem, submenü)
                RootItem.Items.Add(titem)
            End If
        Next
    End Sub
    Sub New(Menü As Menü)
        Me.Menü = Menü
    End Sub
End Class
