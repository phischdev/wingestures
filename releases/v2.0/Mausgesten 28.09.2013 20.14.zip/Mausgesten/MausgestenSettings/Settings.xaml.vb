﻿Imports MahApps
Imports MahApps.Metro.Controls
Imports System.Collections
Imports ExtensionContract
Imports System.ComponentModel.Composition
Imports System.ComponentModel.Composition.Hosting
Imports SharedMethods
Imports System.Reflection
Imports System.Threading.Tasks

Public Class Settings
    Inherits MetroWindow

    <ImportMany(GetType(IExtensionContract))> _
    Property Extensions As IEnumerable(Of Lazy(Of IExtensionContract))
    Property SettingsPath As String = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\WinGestures\SavedSettings.xml"
    Dim DataProvider As XmlDataProvider

    Sub New()

        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.
        DataProvider = New XmlDataProvider()
        Try
            DataProvider.Source = New Uri(SettingsPath)
            DataProvider.Document = New Xml.XmlDocument
            DataProvider.Document.Load(SettingsPath)
        Catch ex As Exception
            Throw ex
        End Try
        TopGrid.DataContext = DataProvider
    End Sub

    Private Sub Settings_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        Dim task As New Task(Sub()
                                 Dim catalog As New DirectoryCatalog(".\Extensions\")
                                 Dim container As New CompositionContainer(catalog)
                                 container.ComposeParts(Me)
                                 For Each Extension As Lazy(Of IExtensionContract) In Extensions
                                     Dispatcher.BeginInvoke(Sub()
                                                                lstExtensions.Items.Add(New AssemblyInfo (Extension))
                                                            End Sub)
                                 Next
                             End Sub)
        task.Start()
        Dim RootMenu As Menü
        RootMenu = Menü.FromXml(DataProvider.Document.SelectSingleNode("/Settings/Menus").InnerXml)
        treeMyConfiguration.Items.Add(New Menu_TreeViewVM(RootMenu).TreeViewData)
        'task.Wait()
        'If lstExtensions.Items.Count > 0 Then lstExtensions.SelectedIndex = 0
    End Sub

    Private Sub lstExtensions_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles lstExtensions.SelectionChanged
        If Not lstExtensions.SelectedItem Is Nothing Then
            Try
                treeThisExtension.Items.Clear()
                Dim MenuXmlDoc As Xml.XmlDocument = DirectCast(lstExtensions.SelectedItem, 
                               AssemblyInfo).Extension.Value.GetUI()

                Dim Menu As SharedMethods.Menü = Menü.FromXml(MenuXmlDoc)
                treeThisExtension.Items.Add(New Menu_TreeViewVM(Menu).TreeViewData)

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnSave_Click(sender As Object, e As RoutedEventArgs) Handles btnSave.Click
        DataProvider.Document.Save(SettingsPath)
        'Me.Close()
    End Sub
End Class