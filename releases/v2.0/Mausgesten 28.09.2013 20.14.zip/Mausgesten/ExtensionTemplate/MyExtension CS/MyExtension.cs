﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExtensionContract;
using System.ComponentModel.Composition;
using System.IO;
using System.Xml;

namespace MyExtension_CS
{

    [Export(typeof(IExtensionContract))]
    public class BasicShortcuts : IExtensionContract
    {


        public BasicShortcuts()
        {
        }


        public void Loaded()
        {
        }

        public void Action(string ID, ActionEventArgs e)
        {
            switch (ID)
            {

            }
        }


        public object Closing()
        {
            return null;
        }


        public void Pause()
        {
        }


        public void Reactivate()
        {
        }

        public XmlDocument GetUI()
        {
            return PrepareMenu.Prepare(System.Reflection.Assembly.GetExecutingAssembly());
        }
    }
}
