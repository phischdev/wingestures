﻿Imports ExtensionContract
Imports System.ComponentModel.Composition
Imports System.IO
Imports System.Xml

<Export(GetType(IExtensionContract))> _
Public Class BasicShortcuts : Implements IExtensionContract

    Public Sub New()

    End Sub

    Public Sub Loaded() Implements IExtensionContract.Loaded

    End Sub

    Public Sub Action(ID As String, e As ActionEventArgs) Implements IExtensionContract.Action
        Select Case ID

        End Select
    End Sub

    Public Function Closing() As Object Implements IExtensionContract.Closing
        Return Nothing
    End Function

    Public Sub Pause() Implements IExtensionContract.Pause

    End Sub

    Public Sub Reactivate() Implements IExtensionContract.Reactivate

    End Sub

    Public Function GetUI() As Xml.XmlDocument Implements IExtensionContract.GetUI
        Return PrepareMenu.Prepare(System.Reflection.Assembly.GetExecutingAssembly)
    End Function
End Class
