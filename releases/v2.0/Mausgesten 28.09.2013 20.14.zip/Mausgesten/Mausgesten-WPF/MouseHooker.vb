﻿Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports SharedMethods

''' <summary>
''' Interaction logic for MouseHooker.xaml
''' Derived from http://blogs.msdn.com/b/toub/archive/2006/05/03/589468.aspx
''' </summary>
Partial Public Class MouseHooker

    Public Sub New()
        _hookID = SetHook(_proc)
    End Sub

    Private Shared ReadOnly _proc As LowLevelMouseProc = AddressOf HookCallback
    Private Shared _hookID As IntPtr = IntPtr.Zero

    Private Shared Function SetHook(proc As LowLevelMouseProc) As IntPtr
        Using curProcess As Process = Process.GetCurrentProcess()
            Using curModule As ProcessModule = curProcess.MainModule
                Return SetWindowsHookEx(WH_MOUSE_LL, proc, GetModuleHandle(curModule.ModuleName), 0)
            End Using
        End Using
    End Function

    Private Delegate Function LowLevelMouseProc(nCode As Integer, wParam As IntPtr, lParam As IntPtr) As IntPtr

    <Flags> _
    Private Enum MouseEventFlags
        LEFTDOWN = &H2
        LEFTUP = &H4
        MIDDLEDOWN = &H20
        MIDDLEUP = &H40
        MOVE = &H1
        ABSOLUTE = &H8000
        RIGHTDOWN = &H8
        RIGHTUP = &H10
    End Enum
    Public Enum MouseMessages
        WM_LBUTTONDOWN = &H201
        WM_LBUTTONUP = &H202

        WM_MButtonDown = &H207
        WM_MButtonUp = &H208

        WM_MOUSEMOVE = &H200
        WM_MOUSEWHEEL = &H20A

        WM_RBUTTONDOWN = &H204
        WM_RBUTTONUP = &H205

        WM_XBUTTONDOWN = &H20B
        WM_XBUTTONUP = &H20C

        MK_XBUTTON1Down = &H20
        MK_XBUTTON2Down = &H40



    End Enum

    Private Shared Function HookCallback(nCode As Integer, wParam As IntPtr, lParam As IntPtr) As IntPtr
        If nCode >= 0 Then
            Select Case CType(wParam, MouseMessages)
                Case MouseMessages.WM_MButtonDown, MouseMessages.WM_MButtonUp, MouseMessages.WM_XBUTTONDOWN, MouseMessages.WM_XBUTTONUP
                    Dim mouseinfo As New MouseInfo With {.nCode = nCode, .wParam = wParam, .lParam = lParam}
                    TransferModul.MainWindows.LastKeyMessage = mouseinfo
            End Select
        End If
    End Function

    Private Const WH_MOUSE_LL As Integer = 14

    <StructLayout(LayoutKind.Sequential)> _
    Public Structure POINT
        Public x As Integer
        Public y As Integer
    End Structure

    <StructLayout(LayoutKind.Sequential)> _
    Public Structure MSLLHOOKSTRUCT
        Public pt As POINT
        Public mouseData As UInteger
        Public flags As UInteger
        Public time As UInteger
        Public dwExtraInfo As IntPtr
    End Structure

    Public Structure MouseInfo
        Public nCode As Integer
        Public wParam As IntPtr
        Public lParam As IntPtr
    End Structure
    <DllImport("user32.dll")> _
    Private Shared Sub mouse_event(dwFlags As Integer, dx As Integer, dy As Integer, dwData As Integer, dwExtraInfo As Integer)
    End Sub

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function SetWindowsHookEx(idHook As Integer, lpfn As LowLevelMouseProc, hMod As IntPtr, dwThreadId As UInteger) As IntPtr
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function UnhookWindowsHookEx(hhk As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function CallNextHookEx(hhk As IntPtr, nCode As Integer, wParam As IntPtr, lParam As IntPtr) As IntPtr
    End Function

    <DllImport("kernel32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Shared Function GetModuleHandle(lpModuleName As String) As IntPtr
    End Function
End Class

Module TransferModul

    Public MainWindows As MainWindow
End Module


