﻿Imports System.Threading.Tasks
Imports System.Windows.Media.Animation
Imports SharedMethods
Imports System.Reflection
Imports System.ComponentModel.Composition.Hosting
Imports System.ComponentModel.Composition
Imports ExtensionContract

Class MainWindow
    WithEvents MouseMovementListener As New MouseMovementListener

    Event StartAction(Befehl As String)


    Dim SysTray As New System.Windows.Forms.NotifyIcon()
    Dim SettingsPath As String = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\WinGestures\SavedSettings.xml"
    <ImportMany(GetType(IExtensionContract))> _
    Property ExtensionAssemblys As IEnumerable(Of Lazy(Of IExtensionContract))
    Private usedExtensions As New List(Of AssemblyInfo)

    Property LastWindowHandle As IntPtr

#Region "Initialisierung"
    Sub New()
        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()

        InitializeSysTray()
        LookForSettings()

        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.
    End Sub

    Private Sub LookForSettings() 'if settings file doesn't exit -> create it
        If Not IO.File.Exists(SettingsPath) Then
            Try
                Dim MyAssembly As Assembly = Assembly.GetExecutingAssembly
                Dim ResourceStream As IO.Stream = MyAssembly.GetManifestResourceStream("WinGestures.StandardSettings.xml")
                IO.Directory.CreateDirectory(IO.Path.GetDirectoryName(SettingsPath))
                Dim FileStream As New IO.FileStream(SettingsPath, IO.FileMode.CreateNew)
                ResourceStream.CopyTo(FileStream)
                FileStream.Flush()
                FileStream.Close()
                ResourceStream.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub InitializeSysTray()
        SysTray.Visible = True

        Dim stream As IO.Stream = Assembly.GetExecutingAssembly.GetManifestResourceStream("WinGestures.PixelIcon_16x16.ico") 'MausIcon.ico") 'IO.File.Open("Assets/MausIcon.ico", IO.FileMode.Open)
        'Dim lst() As String = Assembly.GetExecutingAssembly.GetManifestResourceNames
        SysTray.Icon = New System.Drawing.Icon(stream)
        stream.Close()

        '########################## System Tray #######################
        Dim ContextMenuStrip As New System.Windows.Forms.ContextMenuStrip
        Dim s As New System.Windows.Forms.ToolStripMenuItem

        '############################ active ##########################
        Dim activeItem As New System.Windows.Forms.ToolStripMenuItem With {.Text = "active", .Checked = True}
        AddHandler activeItem.Click, Sub(sender As System.Windows.Forms.ToolStripMenuItem, e As Object)
                                         Active = Not sender.Checked
                                         sender.Checked = Not sender.Checked
                                     End Sub
        ContextMenuStrip.Items.Add(activeItem)

        '########################### settings ##########################
        Dim SettingsItem As New System.Windows.Forms.ToolStripMenuItem With {.Text = "settings"}
        AddHandler SettingsItem.Click, Sub(sender As System.Windows.Forms.ToolStripMenuItem, e As Object)
                                           Try
                                               'Open Settings.exe
                                               Dim Settings As New Diagnostics.Process()
                                               Settings.StartInfo.FileName = IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly.Location) & "\Settings.exe"
                                               Settings.Start()

                                               'pause
                                               SysTray.Visible = False
                                               Dim wasActive = Active
                                               Active = False
                                               Abort = True
                                               Offen = False
                                               Settings.WaitForExit()

                                               'resume
                                               Active = wasActive
                                               SysTray.Visible = True
                                           Catch ex As Exception
                                               MessageBox.Show(ex.Message & vbCrLf & IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly.Location) & "\Settings.exe")
                                           End Try
                                       End Sub
        ContextMenuStrip.Items.Add(SettingsItem)

        '############################### seperator ######################
        ContextMenuStrip.Items.Add(New System.Windows.Forms.ToolStripSeparator)

        '################################# exit #########################
        Dim exitItem As New System.Windows.Forms.ToolStripMenuItem With {.Text = "exit"}
        AddHandler exitItem.Click, Sub(sender As System.Windows.Forms.ToolStripMenuItem, e As Object)
                                       Me.Close()
                                   End Sub
        ContextMenuStrip.Items.Add(exitItem)


        SysTray.ContextMenuStrip = ContextMenuStrip
    End Sub

#End Region

#Region "HotKey / Fenster öffnen, schließen"

    Private Sub HotKeyOpen(hookStruct As MouseHooker.MSLLHOOKSTRUCT)
        Dim currentWindowHandle = Win32.User.GetForegroundWindow()
        If Not currentWindowHandle = (New Interop.WindowInteropHelper(Application.Current.MainWindow)).Handle Then
            LastWindowHandle = currentWindowHandle
        End If
        Dispatcher.BeginInvoke(Sub()
                                   SetPosition(New Point(
                                               hookStruct.pt.x - Me.ActualWidth / 2,
                                               hookStruct.pt.y - Me.ActualHeight / 2))
                               End Sub)
        Offen = True
    End Sub

    Private Sub HotKeyClose()
        Offen = False
    End Sub

    Dim _LastKeyMessage As MouseHooker.MouseInfo
    Public Property LastKeyMessage As MouseHooker.MouseInfo
        Set(value As MouseHooker.MouseInfo)
            If Not Active Then Exit Property

            _LastKeyMessage = value
            Dim hookStruct = CType(Runtime.InteropServices.Marshal.PtrToStructure(_LastKeyMessage.lParam,
                                                                              GetType(MouseHooker.MSLLHOOKSTRUCT)), 
                                                                                      MouseHooker.MSLLHOOKSTRUCT)
            Dim HotKey As HotKey = SettingsHelper.GetValue("HotKey")

            Dim xbutton = HIWORD(hookStruct.mouseData)
            Select Case _LastKeyMessage.wParam
                Case MouseHooker.MouseMessages.WM_MButtonDown
                    If HotKey = SharedMethods.HotKey.MiddleMouseButton Then HotKeyOpen(hookStruct)
                Case MouseHooker.MouseMessages.WM_XBUTTONDOWN
                    If HotKey = xbutton Then HotKeyOpen(hookStruct)
                Case MouseHooker.MouseMessages.WM_MButtonUp
                    If HotKey = SharedMethods.HotKey.MiddleMouseButton Then HotKeyClose()
                Case MouseHooker.MouseMessages.WM_XBUTTONUP
                    If HotKey = xbutton Then HotKeyClose()
            End Select
        End Set
        Get

        End Get
    End Property

    Private Shared Function HIWORD(inp As UInt32) As UInteger
        '???
        Return (inp >> 16)
    End Function

    Private Sub SetPosition(Position As Point)
        'Stop current animation -> then set values
        Me.BeginAnimation(MainWindow.TopProperty, Nothing)
        Me.BeginAnimation(MainWindow.LeftProperty, Nothing)
        Me.SetValue(MainWindow.LeftProperty, Position.X)
        Me.SetValue(MainWindow.TopProperty, Position.Y)
    End Sub

    Dim _Offen As Boolean
    Public Property Offen As Boolean
        Get
            Return _Offen
        End Get

        Set(ByVal value As Boolean)
            Dispatcher.BeginInvoke(Sub()
                                       _Offen = value
                                       MouseMovementListener.Listen = value
                                       If value Then
                                           Abort = False
                                           Me.MyDataContext = New ViewModels.MenüViewModel(SettingsHelper.GetRootMenu)
                                           DirectCast(FindResource("ÖffnenSB"), Animation.Storyboard).Begin()
                                       Else
                                           If Not DirectCast(Me.DataContext, ViewModels.MenüViewModel).Menü.Position = Direction.Root And Not Abort Then
                                               Dispatcher.BeginInvoke(Sub()
                                                                          RaiseEvent StartAction(DirectCast(Me.DataContext, ViewModels.MenüViewModel).Menü.Befehl)
                                                                      End Sub)
                                           Else
                                               DirectCast(FindResource("AbortSB"), Animation.Storyboard).Begin()
                                           End If
                                           DirectCast(FindResource("SchließenSB"), Animation.Storyboard).Begin()
                                       End If
                                   End Sub)

        End Set
    End Property
#End Region

#Region "Fenster verschieben"

    Private Sub SelectMenu(direction As Direction)
        Dim MoveWindowAni As New DoubleAnimation
        MoveWindowAni.Duration = TimeSpan.FromMilliseconds(150)
        Dim AniSB As Storyboard

        Select Case direction
            Case direction.Left
                MoveWindowAni.From = Me.Left
                MoveWindowAni.To = Me.Left - 45
                AniSB = FindResource("LinksSB")

            Case direction.Right
                MoveWindowAni.From = Me.Left
                MoveWindowAni.To = Me.Left + 45
                AniSB = FindResource("RechtsSB")
            Case direction.Up
                MoveWindowAni.From = Me.Top
                MoveWindowAni.To = Me.Top - 55
                AniSB = FindResource("HochSB")
            Case direction.Down
                MoveWindowAni.From = Me.Top
                MoveWindowAni.To = Me.Top + 55
                AniSB = FindResource("RunterSB")
        End Select
        'Get current Menu -> take submenu for a specific direction -> load it
        Me.MyDataContext = New ViewModels.MenüViewModel(DirectCast(
                                                        Me.DataContext, ViewModels.MenüViewModel).Menü.Untermenüs(direction))

        'Start both animations (Window and Controls in window) at the same time
        Me.BeginAnimation(
            If(direction = direction.Up Or direction = direction.Down,
               Windows.Window.TopProperty,
               Windows.Window.LeftProperty),
           MoveWindowAni)

        AniSB.Begin()
    End Sub

    Private Sub MouseMovementListener_MouseMoved(Direction As Direction) Handles MouseMovementListener.MouseMoved
        Dispatcher.BeginInvoke(Sub()
                                   If Not DirectCast(Me.DataContext, ViewModels.MenüViewModel).Menü.Position = Direction Then
                                       If DirectCast(Me.DataContext, ViewModels.MenüViewModel).HasMenuForDirection(Direction) Then
                                           SelectMenu(Direction)
                                       Else
                                           Abort = True
                                           Offen = False
                                       End If
                                   End If
                               End Sub)
    End Sub

#End Region

    Dim SettingsHelper As SettingsHelper
    Dim RootView As Menü
    Private Abort As Boolean

    Private Sub MainWindow_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        SettingsHelper = New SettingsHelper(SettingsPath)

        'task looks for all available extensions 
        Dim task As New Task(Sub()
                                 Dim catalog As New DirectoryCatalog(".\Extensions\")
                                 Dim container As New CompositionContainer(catalog)
                                 container.ComposeParts(Me)
                                 For Each Extension As Lazy(Of IExtensionContract) In ExtensionAssemblys
                                     Dim ai As New AssemblyInfo(Extension)

                                     If SettingsHelper.UsedExtensionIDRoots.Contains(ai.ExtensionIDRoot) Then  'if the extension is needed then ...
                                         usedExtensions.Add(ai) 'add it to this list ...
                                         Dim t As New Task(Sub()
                                                               ai.Extension.Value.Loaded() 'and raise "loaded" event
                                                           End Sub)
                                         t.Start()
                                     End If
                                 Next
                             End Sub)
        Dispatcher.BeginInvoke(Sub()
                                   task.Start()
                               End Sub)

        'active on start?
        _Active = SettingsHelper.GetValue("ActiveOnStart")
        DirectCast(SysTray.ContextMenuStrip.Items(0), Forms.ToolStripMenuItem).Checked = Active

        'mousehooker
        TransferModul.MainWindows = Me
        Dim mh As New MouseHooker

        'set start menu
        Me.MyDataContext = New ViewModels.MenüViewModel(SettingsHelper.GetRootMenu)
    End Sub

    Private Sub MainWindow_Closing(sender As Object, e As ComponentModel.CancelEventArgs) Handles Me.Closing
        SysTray.Visible = False
    End Sub


    Dim _Active As Boolean = True
    Property Active As Boolean
        Get
            Return _Active
        End Get
        Set(value As Boolean)
            _Active = value
            For Each Extension As AssemblyInfo In usedExtensions 'If paused also pause all extensions
                Dim t As New Task(Sub()
                                      If value Then
                                          Extension.Extension.Value.Reactivate()
                                      Else
                                          Extension.Extension.Value.Pause()
                                      End If
                                  End Sub)
                t.Start()
            Next
        End Set
    End Property

    WriteOnly Property MyDataContext As Object 'Actually just a function to set the DataContext
        Set(value As Object)
            Dim ViewModel As ViewModels.MenüViewModel = value
            Dispatcher.BeginInvoke(Sub()
                                       Dim German() As String = {"Hoch", "Runter", "Links", "Rechts"}

                                       'Prepare view for rootMenu
                                       If ViewModel.Menü.Position = Direction.Root Then
                                           DirectCast(FindResource("StandartSB"), Storyboard).Begin()
                                       End If

                                       For i As Integer = 0 To 3 'For each possible Direction -> get the name of the needed Storyboard -> and start
                                           Dim strExtra = If(ViewModel.HasMenuForDirection(i), "U", "")
                                           Dim SB As Storyboard = FindResource(strExtra & German(i) & "SB")
                                           If Not (ViewModel.Menü.Position = Direction.Root And strExtra = "U") Then SB.Begin()
                                       Next
                                   End Sub)

            For i As Integer = 0 To 3 'For each possible Direction -> set the mouse movement threshold
                MouseMovementListener.Schwellen(i) = If(ViewModel.HasMenuForDirection(i),
                                                        SettingsHelper.GetValue("SlidingThreshold"),
                                                        SettingsHelper.GetValue("AbortingThreshold"))
            Next
            Me.DataContext = value
        End Set
    End Property

    Private Sub MainWindow_StartAction(ActionID As String) Handles Me.StartAction
        'Just for debugging
        Debug.Print(Date.Now.TimeOfDay.ToString & "  send " & ActionID)

        'ActionID will be like: "Author.Extension.Action"
        Dim Splits() As String = ActionID.Split(New String() {"."}, 3, StringSplitOptions.None)
        If Splits.Length = 3 Then
            'Take the first Extension that fits to the ActionID
            Dim myExtension = usedExtensions.FirstOrDefault(Function(ext) ext.Author = Splits(0) And ext.Name = Splits(1))
            If Not myExtension Is Nothing Then
                Dim t As New Task(Sub()
                                      myExtension.Extension.Value.Action(Splits(2), New ActionEventArgs(LastWindowHandle))
                                  End Sub)
                t.Start()
            Else
                MessageBox.Show("Extension not found: " & Splits(0) & "." & Splits(1))
            End If
        End If
    End Sub
End Class