﻿Imports System.Xml
Imports SharedMethods
Imports System.Reflection

Public Class SettingsHelper
    Dim MyDoc As Xml.XmlDocument
    Private Path As String
    Private RootMenu As Menü
    Public Property UsedExtensionIDRoots As List(Of String)

    Sub New(Path As String)
        Me.Path = Path
        Dim filewatcher As New IO.FileSystemWatcher(IO.Path.GetDirectoryName(Path))
        filewatcher.NotifyFilter = IO.NotifyFilters.LastWrite
        filewatcher.Filter = IO.Path.GetFileName(Path)
        filewatcher.EnableRaisingEvents = True

        AddHandler filewatcher.Changed, Sub(sender As Object, e As System.IO.FileSystemEventArgs)
                                            If e.ChangeType = IO.WatcherChangeTypes.Changed Then
                                                Try
                                                    MyDoc.Load(Path)
                                                    Reload()
                                                Catch ex As Exception
                                                    Debug.Print(ex.Message)
                                                End Try
                                            End If
                                        End Sub
        MyDoc = New Xml.XmlDocument
        Try
            MyDoc.Load(Path)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Reload()
    End Sub

    Public Sub Reload()
        Dim xml As String = MyDoc.SelectSingleNode("/Settings/Menus").InnerXml
        RootMenu = Menü.FromXml(xml)
        UsedExtensionIDRoots = GetAllActionRoots()
        InstallMeOnStartUp(Boolean.Parse(GetValue("LaunchOnStartup")))
    End Sub

    Private Function GetAllActionRoots() As List(Of String)
        Dim l As New List(Of String)
        Dim Menus = MyDoc.SelectNodes("//Menu")
        For Each Menu As XmlNode In Menus
            Dim Stamm As String
            Dim ActionIDSplit() As String = Menu.Attributes("Action").InnerText.Split(New String() {"."}, 3, StringSplitOptions.None)
            If ActionIDSplit.Count = 3 Then
                Stamm = ActionIDSplit(0) & "." & ActionIDSplit(1)
                l.Add(Stamm)
            End If

        Next
        Return l.Distinct().ToList
    End Function

    Public Function GetValue(ByVal Key As String) As String
        Dim Node As XmlNode = MyDoc.SelectSingleNode("/Settings/" & Key)
        Return Node.InnerText
    End Function

    Public Function GetRootMenu() As Menü
        Return RootMenu
    End Function

    Public Sub WriteValue(ByVal Key As String, Value As String)
        MyDoc.SelectSingleNode("/Settings/" & Key).InnerText = Value
        'MyDoc.Save(Path)
    End Sub

    Private Sub InstallMeOnStartUp(start As Boolean)
        Try
            Dim key As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
            Dim curAssembly As Assembly = Assembly.GetExecutingAssembly()
            If start Then
                key.SetValue(curAssembly.GetName().Name, curAssembly.Location)
            Else
                key.DeleteValue(curAssembly.GetName.Name, False)
            End If
        Catch
        End Try
    End Sub
End Class
