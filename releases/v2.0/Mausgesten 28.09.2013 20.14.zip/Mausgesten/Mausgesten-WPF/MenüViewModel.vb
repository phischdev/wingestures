﻿Imports SharedMethods

Namespace ViewModels

    Public Class MenüViewModel : Inherits DependencyObject
        Private Property _Menü As Menü

        Public ReadOnly Property Menü As Menü
            Get
                Return _Menü
            End Get
        End Property

        Private Function GetLabelForDirection(direction As Direction)
            If Not _Menü.Untermenüs(direction) Is Nothing Then
                Return _Menü.Untermenüs(direction).Titel
            ElseIf _Menü.Position = direction Then
                Return _Menü.Titel
            Else
                Return String.Empty
            End If
        End Function

        Public Function HasMenuForDirection(direction As Direction)
            Return Not _Menü.Untermenüs(direction) Is Nothing
        End Function

        Public ReadOnly Property Links As String
            Get
                Return GetLabelForDirection(Direction.Left)
            End Get
        End Property

        Public ReadOnly Property Rechts As String
            Get
                Return GetLabelForDirection(Direction.Right)
            End Get
        End Property

        Public ReadOnly Property Oben As String
            Get
                Return GetLabelForDirection(Direction.Up)
            End Get
        End Property

        Public ReadOnly Property Unten As String
            Get
                Return GetLabelForDirection(Direction.Down)
            End Get
        End Property

        Public ReadOnly Property HasRechts As Boolean
            Get
                Return HasMenuForDirection(Rechts) Is Nothing
            End Get
        End Property

        Public ReadOnly Property HasOben As Boolean
            Get
                Return HasMenuForDirection(Oben) Is Nothing
            End Get
        End Property

        Public ReadOnly Property HasUnten As Boolean
            Get
                Return HasMenuForDirection(Unten) Is Nothing
            End Get
        End Property

        Public ReadOnly Property HasLinks As Boolean
            Get
                Return HasMenuForDirection(Links) Is Nothing
            End Get
        End Property

        Sub New(Menü As Menü)
            Me._Menü = Menü
        End Sub

        Sub New()

        End Sub
    End Class
End Namespace