﻿Imports SharedMethods

Public Class MouseMovementListener
    WithEvents tmr As New Timers.Timer With {.Enabled = False, .Interval = 50}
    Dim LastPos As System.Drawing.Point

    Event MouseMoved(ByVal Direction As Direction)

    Property Listen As Boolean
        Set(value As Boolean)
            tmr.Enabled = value
            If value Then
                Dim point = System.Windows.Forms.Control.MousePosition
                LastPos = point
            End If
        End Set
        Get
            Return tmr.Enabled
        End Get
    End Property

    Public Schwellen(3) As Double

    Private Sub tmr_Elapsed(sender As Object, e As Timers.ElapsedEventArgs) Handles tmr.Elapsed
        Dim point = System.Windows.Forms.Control.MousePosition
        Dim diff As System.Drawing.Point = System.Drawing.Point.Subtract(LastPos, point)

        If diff.X > Schwellen(Direction.Left) Then
            Moved(Direction.Left)
        ElseIf diff.X < -Schwellen(Direction.Right) Then
            Moved(Direction.Right)
        ElseIf diff.Y > Schwellen(Direction.Up) Then
            Moved(Direction.Up)
        ElseIf diff.Y < -Schwellen(Direction.Down) Then
            Moved(Direction.Down)
        End If
    End Sub

    Private Sub Moved(direction As Direction)
        LastPos = System.Windows.Forms.Control.MousePosition
        RaiseEvent MouseMoved(direction)
    End Sub
End Class
