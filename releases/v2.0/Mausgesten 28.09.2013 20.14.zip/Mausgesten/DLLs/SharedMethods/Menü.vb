﻿Public Class Menü
    Property Titel As String
    Property Befehl As String
    Property Parent As Menü

    ReadOnly Property Position As Direction
        Get
            If Parent IsNot Nothing Then
                Return CType(Parent.Untermenüs.ToList.IndexOf(Me), Direction)
            Else
                Return Direction.Root
            End If
        End Get
    End Property

    Public Untermenüs(3) As Menü

    Sub New(Titel As String, Befehl As String, Parent As Menü)
        Me.Titel = Titel
        Me.Befehl = Befehl
        Me.Parent = Parent
    End Sub

    Public Shared Function FromXml(ByVal xml As String)
        Return XmlHelper.XmlToMenu(xml)
    End Function
    Public Shared Function FromXml(ByVal xmlDoc As Xml.XmlDocument)
        Return XmlHelper.XmlToMenu(xmlDoc)
    End Function
End Class