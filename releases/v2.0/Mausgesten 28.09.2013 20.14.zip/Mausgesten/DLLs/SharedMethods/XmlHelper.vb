﻿Imports System.Xml

Public Class XmlHelper
    Public Shared Function XmlToMenu(ByVal xml As String) As Menü
        Try
            Dim xmldoc As New XmlDocument
            xmldoc.LoadXml(xml)

            Return XmlToMenu(xmldoc)
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function XmlToMenu(ByVal xmlDocument As XmlDocument) As Menü
        Try
            Dim RootNode = xmlDocument.LastChild

            Dim rootergebnis = MenüFromNode(RootNode, Nothing)
            Dim RootMenü = DirectCast(rootergebnis(0), Menü)

            GetSubMenus(RootMenü, RootNode)

            Return RootMenü
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Shared Sub GetSubMenus(rootMenü As Menü, rootNode As XmlNode)
        For Each SubMenuNode As XmlNode In rootNode.ChildNodes
            Dim Ergebnis = MenüFromNode(SubMenuNode, rootMenü)
            Dim SubMenü As Menü = Ergebnis(0)
            ' If SubMenü.Position = Direction.Root Then Throw New Exception("Root Exception")
            GetSubMenus(SubMenü, SubMenuNode)
            If rootMenü.Untermenüs(Ergebnis(1)) IsNot Nothing Then Throw New Exception("Can't have more than 3 Submenus")
            rootMenü.Untermenüs(Ergebnis(1)) = SubMenü
        Next
    End Sub

    Private Shared Function MenüFromNode(xmlNode As XmlNode, root As Menü) As Object
        Dim Titel As String = xmlNode.Attributes("Title").Value
        Dim Befehl As String = xmlNode.Attributes("Action").Value
        Dim Position As String = xmlNode.Attributes("Position").Value
        Dim Pos As Direction
        If [Enum].IsDefined(GetType(Direction), Position) Then
            Pos = [Enum].Parse(GetType(Direction), Position)
        Else
            Throw New Exception("XML is invalid")
        End If
        Dim Menü As New Menü(Titel, Befehl, root)
        Return {Menü, Pos}
    End Function
End Class
